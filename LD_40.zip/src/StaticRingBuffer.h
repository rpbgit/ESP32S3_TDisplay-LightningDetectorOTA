#ifndef STATIC_RING_BUFFER_H
#define STATIC_RING_BUFFER_H

#include <Arduino.h> // For Serial
#include <cstring>
#include <cstdio>
#include <cstddef>

// Adjust these as needed for memory constraints
constexpr size_t BUFFER_SIZE = 8;
constexpr size_t STRING_LENGTH = 64;

class StaticRingBuffer {
    char buffer[BUFFER_SIZE][STRING_LENGTH] = {};
    size_t head = 0;
    size_t count = 0;
    mutable size_t readIndex = 0;

public:
    /**
     * @brief Adds a string to the ring buffer. Overwrites the oldest entry if the buffer is full.
     * @note This is a destructive operation if the buffer is full, as it overwrites the oldest element.
     * @param str The string to add to the buffer.
     */
    void put(const char* str) {
        std::snprintf(buffer[head], STRING_LENGTH, "%s", str);
        head = (head + 1) % BUFFER_SIZE;
        if (count < BUFFER_SIZE) ++count;
    }

    /**
     * @brief Retrieves a string at a specific index relative to the oldest entry.
     * @note This is a non-destructive operation.
     * @param index The index of the string to retrieve (0 is the oldest).
     * @param outStr The buffer to store the retrieved string.
     * @param outSize The size of the output buffer.
     * @return True if the string was successfully retrieved, false otherwise.
     */
    bool get(size_t index, char* outStr, size_t outSize) const {
        if (index >= count || outSize == 0) return false;
        size_t pos = (head + BUFFER_SIZE - count + index) % BUFFER_SIZE;
        std::strncpy(outStr, buffer[pos], outSize);
        outStr[outSize - 1] = '\0';
        return true;
    }

    /**
     * @brief Concatenates all strings in the buffer into a single string.
     * @note This is a non-destructive operation.
     * @param outStr The buffer to store the concatenated result.
     * @param outSize The size of the output buffer.
     */
    void concatenate(char* outStr, size_t outSize) const {
        if (outSize == 0) return;
        outStr[0] = '\0';
        for (size_t i = 0; i < count; ++i) {
            size_t pos = (head + BUFFER_SIZE - count + i) % BUFFER_SIZE;
            std::strncat(outStr, buffer[pos], outSize - std::strlen(outStr) - 1);
        }
    }

    /**
     * @brief Concatenates all strings in the buffer with a separator between them.
     * @note This is a non-destructive operation.
     * @param outStr The buffer to store the concatenated result.
     * @param outSize The size of the output buffer.
     * @param sep The separator string to insert between entries.
     */
    void concatenateWithSeparator(char* outStr, size_t outSize, const char* sep) const {
        if (outSize == 0) return;
        outStr[0] = '\0';
        for (size_t i = 0; i < count; ++i) {
            size_t pos = (head + BUFFER_SIZE - count + i) % BUFFER_SIZE;
            std::strncat(outStr, buffer[pos], outSize - std::strlen(outStr) - 1);
            if (i < count - 1) {
                std::strncat(outStr, sep, outSize - std::strlen(outStr) - 1);
            }
        }
    }

    /**
     * @brief Concatenates all strings in the buffer into a single string and removes them from the buffer.
     * @note This is a destructive operation. It clears the buffer after concatenation.
     * @param outStr The buffer to store the concatenated result.
     * @param outSize The size of the output buffer.
     */
    void concatenateAndRemove(char* outStr, size_t outSize) {
        if (outSize == 0) return;
        outStr[0] = '\0';

        while (count > 0) {
            size_t pos = (head + BUFFER_SIZE - count) % BUFFER_SIZE;
            std::strncat(outStr, buffer[pos], outSize - std::strlen(outStr) - 1);
            --count; // Remove the oldest element
        }
    }

    /**
     * @brief Concatenates all strings in the buffer with a separator between them and removes them from the buffer.
     * @note This is a destructive operation. It clears the buffer after concatenation.
     * @param outStr The buffer to store the concatenated result.
     * @param outSize The size of the output buffer.
     * @param sep The separator string to insert between entries.
     */
    void concatenateWithSeparatorAndRemove(char* outStr, size_t outSize, const char* sep) {
        if (outSize == 0) return;
        outStr[0] = '\0';

        while (count > 0) {
            size_t pos = (head + BUFFER_SIZE - count) % BUFFER_SIZE;
            std::strncat(outStr, buffer[pos], outSize - std::strlen(outStr) - 1);
            --count; // Remove the oldest element

            // Add separator if there are more elements
            if (count > 0) {
                std::strncat(outStr, sep, outSize - std::strlen(outStr) - 1);
            }
        }
    }

    /**
     * @brief Resets the read index used by getNext().
     * @note This is a non-destructive operation.
     */
    void resetRead() const { readIndex = 0; }

    /**
     * @brief Retrieves the next string in the buffer sequentially, starting from the oldest.
     * @note This is a non-destructive operation.
     * @param outStr The buffer to store the retrieved string.
     * @param outSize The size of the output buffer.
     * @return True if the string was successfully retrieved, false otherwise.
     */
    bool getNext(char* outStr, size_t outSize) const {
        if (readIndex >= count || outSize == 0) return false;
        size_t pos = (head + BUFFER_SIZE - count + readIndex) % BUFFER_SIZE;
        std::strncpy(outStr, buffer[pos], outSize);
        outStr[outSize - 1] = '\0';
        ++readIndex;
        return true;
    }

    /**
     * @brief Checks if the buffer is full.
     * @note This is a non-destructive operation.
     * @return True if the buffer is full, false otherwise.
     */
    bool isFull() const { return count == BUFFER_SIZE; }

    /**
     * @brief Checks if the buffer is empty.
     * @note This is a non-destructive operation.
     * @return True if the buffer is empty, false otherwise.
     */
    bool isEmpty() const { return count == 0; }

    /**
     * @brief Gets the number of elements currently in the buffer.
     * @note This is a non-destructive operation.
     * @return The number of elements in the buffer.
     */
    size_t size() const { return count; }

    /**
     * @brief Gets the maximum capacity of the buffer.
     * @note This is a non-destructive operation.
     * @return The maximum number of elements the buffer can hold.
     */
    size_t capacity() const { return BUFFER_SIZE; }

    /**
     * @brief Clears all elements from the buffer.
     * @note This is a destructive operation. It removes all elements from the buffer.
     */
    void clear() {
        head = 0;
        count = 0;
        readIndex = 0;
    }

    /**
     * @brief Prints the contents of the buffer to the Serial monitor for debugging.
     * @note This is a non-destructive operation.
     */
    void debugPrint() const {
        printf("Buffer contents (%zu entries):\n", count);
        for (size_t i = 0; i < count; ++i) {
            size_t pos = (head + BUFFER_SIZE - count + i) % BUFFER_SIZE;
            Serial.printf(" [%zu] %s\n", i, buffer[pos]);
        }
    }

    /**
     * @brief Retrieves the oldest string in the buffer without removing it.
     * @note This is a non-destructive operation.
     * @param outStr The buffer to store the retrieved string.
     * @param outSize The size of the output buffer.
     * @return True if the string was successfully retrieved, false otherwise.
     */
    bool peekOldest(char* outStr, size_t outSize) const {
        return get(0, outStr, outSize);
    }

    /**
     * @brief Retrieves the newest string in the buffer without removing it.
     * @note This is a non-destructive operation.
     * @param outStr The buffer to store the retrieved string.
     * @param outSize The size of the output buffer.
     * @return True if the string was successfully retrieved, false otherwise.
     */
    bool peekNewest(char* outStr, size_t outSize) const {
        if (count == 0 || outSize == 0) return false;
        size_t pos = (head + BUFFER_SIZE - 1) % BUFFER_SIZE;
        std::strncpy(outStr, buffer[pos], outSize);
        outStr[outSize - 1] = '\0';
        return true;
    }

    /**
     * @brief Checks if the buffer contains a specific string.
     * @note This is a non-destructive operation.
     * @param target The string to search for.
     * @return True if the string is found, false otherwise.
     */
    bool contains(const char* target) const {
        for (size_t i = 0; i < count; ++i) {
            size_t pos = (head + BUFFER_SIZE - count + i) % BUFFER_SIZE;
            if (std::strcmp(buffer[pos], target) == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * @brief Finds the index of a specific string in the buffer.
     * @note This is a non-destructive operation.
     * @param target The string to search for.
     * @return The index of the string if found, or -1 if not found.
     */
    int findIndex(const char* target) const {
        for (size_t i = 0; i < count; ++i) {
            size_t pos = (head + BUFFER_SIZE - count + i) % BUFFER_SIZE;
            if (std::strcmp(buffer[pos], target) == 0) {
                return static_cast<int>(i);
            }
        }
        return -1;
    }

    /**
     * @brief Removes the oldest string from the buffer.
     * @note This is a destructive operation.
     * @return True if the oldest string was successfully removed, false otherwise.
     */
    bool removeOldest() {
        if (count == 0) return false;
        --count;
        return true;
    }
};

#endif // STATIC_RING_BUFFER_H
